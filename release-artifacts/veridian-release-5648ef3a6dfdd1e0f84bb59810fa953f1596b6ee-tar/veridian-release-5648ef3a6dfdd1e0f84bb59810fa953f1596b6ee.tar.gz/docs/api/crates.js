window.ALL_CRATES = ["veridian_kernel"];
//{"start":21,"fragment_lengths":[17]}