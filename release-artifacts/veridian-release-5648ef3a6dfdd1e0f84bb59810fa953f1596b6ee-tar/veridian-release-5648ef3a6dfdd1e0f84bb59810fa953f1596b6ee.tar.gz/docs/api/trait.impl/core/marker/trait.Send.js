(function() {
    var implementors = Object.fromEntries([["veridian_kernel",[["impl !Send for <a class=\"struct\" href=\"veridian_kernel/bench/struct.BenchmarkHarness.html\" title=\"struct veridian_kernel::bench::BenchmarkHarness\">BenchmarkHarness</a>",1,["veridian_kernel::bench::BenchmarkHarness"]],["impl Send for <a class=\"enum\" href=\"veridian_kernel/enum.QemuExitCode.html\" title=\"enum veridian_kernel::QemuExitCode\">QemuExitCode</a>",1,["veridian_kernel::test_framework::QemuExitCode"]],["impl Send for <a class=\"struct\" href=\"veridian_kernel/bench/struct.BenchmarkResult.html\" title=\"struct veridian_kernel::bench::BenchmarkResult\">BenchmarkResult</a>",1,["veridian_kernel::bench::BenchmarkResult"]],["impl Send for <a class=\"struct\" href=\"veridian_kernel/serial/struct.SerialPort.html\" title=\"struct veridian_kernel::serial::SerialPort\">SerialPort</a>",1,["veridian_kernel::serial::SerialPort"]]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[867]}