(function() {
    var implementors = Object.fromEntries([["veridian_kernel",[["impl Default for <a class=\"struct\" href=\"veridian_kernel/bench/struct.BenchmarkHarness.html\" title=\"struct veridian_kernel::bench::BenchmarkHarness\">BenchmarkHarness</a>"]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[201]}