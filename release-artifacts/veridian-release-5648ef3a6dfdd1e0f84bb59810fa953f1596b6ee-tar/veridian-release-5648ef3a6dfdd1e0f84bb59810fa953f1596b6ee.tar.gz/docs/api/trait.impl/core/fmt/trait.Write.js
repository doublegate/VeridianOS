(function() {
    var implementors = Object.fromEntries([["veridian_kernel",[["impl Write for <a class=\"struct\" href=\"veridian_kernel/serial/struct.SerialPort.html\" title=\"struct veridian_kernel::serial::SerialPort\">SerialPort</a>"]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[183]}