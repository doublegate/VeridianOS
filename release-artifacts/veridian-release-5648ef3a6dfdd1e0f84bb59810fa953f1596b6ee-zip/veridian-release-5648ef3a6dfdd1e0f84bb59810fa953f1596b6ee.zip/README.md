# VeridianOS Release Artifacts

This package contains the official VeridianOS release artifacts.

## 📦 Package Contents

### Kernel Images (`kernel/`)
- `x86_64/veridian-kernel` - Intel/AMD 64-bit kernel
- `aarch64/veridian-kernel` - ARM 64-bit kernel
- `riscv64gc/veridian-kernel` - RISC-V 64-bit kernel with G+C extensions

### Debug Symbols (`symbols/`)
Matching debug symbols for each kernel image, useful for:
- GDB debugging
- Crash analysis
- Performance profiling

### Documentation (`docs/`)
- `index.html` - Documentation portal
- `api/` - Rust API documentation
- `guide/` - Developer guide (mdBook)

## 🚀 Quick Start

### Running with QEMU
```bash
# x86_64
qemu-system-x86_64 -kernel kernel/x86_64/veridian-kernel -serial stdio

# AArch64
qemu-system-aarch64 -M virt -cpu cortex-a72 -kernel kernel/aarch64/veridian-kernel -serial stdio

# RISC-V
qemu-system-riscv64 -M virt -kernel kernel/riscv64gc/veridian-kernel -serial stdio
```

### Debugging
```bash
# Start QEMU with GDB server
qemu-system-x86_64 -kernel kernel/x86_64/veridian-kernel -s -S

# In another terminal
gdb kernel/x86_64/veridian-kernel
(gdb) target remote :1234
(gdb) continue
```

## 📋 Build Information
- **Git SHA**: 5648ef3a6dfdd1e0f84bb59810fa953f1596b6ee
- **Git Ref**: refs/heads/main
- **Build Date**: $(date -u +"%Y-%m-%d %H:%M:%S UTC")
- **Rust Version**: nightly-2025-01-15

## 📚 Resources
- [GitHub Repository](https://github.com/doublegate/VeridianOS)
- [Issue Tracker](https://github.com/doublegate/VeridianOS/issues)
- [Documentation](https://doublegate.github.io/VeridianOS/)

## ⚖️ License
VeridianOS is licensed under the MIT License.
