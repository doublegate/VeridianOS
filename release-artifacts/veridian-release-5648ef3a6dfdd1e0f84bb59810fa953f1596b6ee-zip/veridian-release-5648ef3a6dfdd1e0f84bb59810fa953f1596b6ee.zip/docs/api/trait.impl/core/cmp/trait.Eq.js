(function() {
    var implementors = Object.fromEntries([["veridian_kernel",[["impl Eq for <a class=\"enum\" href=\"veridian_kernel/enum.QemuExitCode.html\" title=\"enum veridian_kernel::QemuExitCode\">QemuExitCode</a>"]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[165]}