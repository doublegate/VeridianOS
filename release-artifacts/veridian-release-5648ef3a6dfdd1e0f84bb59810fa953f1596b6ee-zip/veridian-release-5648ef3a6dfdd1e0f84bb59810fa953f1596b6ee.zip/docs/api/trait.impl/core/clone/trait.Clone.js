(function() {
    var implementors = Object.fromEntries([["veridian_kernel",[["impl Clone for <a class=\"enum\" href=\"veridian_kernel/enum.QemuExitCode.html\" title=\"enum veridian_kernel::QemuExitCode\">QemuExitCode</a>"],["impl Clone for <a class=\"struct\" href=\"veridian_kernel/bench/struct.BenchmarkResult.html\" title=\"struct veridian_kernel::bench::BenchmarkResult\">BenchmarkResult</a>"]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[343]}